//! Ethereum specific

// HTML documentation attributes
#![doc(
    html_logo_url = "https://raw.githubusercontent.com/paradigmxyz/reth/main/assets/reth-docs.png",
    html_favicon_url = "https://avatars0.githubusercontent.com/u/97369466?s=256",
    issue_tracker_base_url = "https://github.com/paradigmxyz/reth/issues/"
)]

// Conditionally warn unused crate dependencies except in tests
#![cfg_attr(not(test), warn(unused_crate_dependencies))]

// Conditionally enable features for documentation
#![cfg_attr(docsrs, feature(doc_cfg, doc_auto_cfg))]

// Module declaration for `payload`
mod payload;

// Publicly re-export symbols from `payload`
pub use payload::{EthBuiltPayload, EthPayloadBuilderAttributes};

// External imports
use reth_chainspec::ChainSpec;
use reth_engine_primitives::EngineTypes;
use reth_payload_primitives::{
    validate_version_specific_fields, EngineApiMessageVersion, EngineObjectValidationError,
    PayloadOrAttributes, PayloadTypes,
};
pub use reth_rpc_types::{
    engine::{
        ExecutionPayloadEnvelopeV2, ExecutionPayloadEnvelopeV3, ExecutionPayloadEnvelopeV4,
        PayloadAttributes as EthPayloadAttributes,
    },
    ExecutionPayloadV1,
};

/// The types used in the default mainnet ethereum beacon consensus engine.
#[derive(Debug, Default, Clone, serde::Deserialize, serde::Serialize)]
#[non_exhaustive]
pub struct EthEngineTypes;

// Implementation of `PayloadTypes` for `EthEngineTypes`
impl PayloadTypes for EthEngineTypes {
    type BuiltPayload = EthBuiltPayload; // Define type for built payloads
    type PayloadAttributes = EthPayloadAttributes; // Define type for payload attributes
    type PayloadBuilderAttributes = EthPayloadBuilderAttributes; // Define type for payload builder attributes
}

// Implementation of `EngineTypes` for `EthEngineTypes`
impl EngineTypes for EthEngineTypes {
    type ExecutionPayloadV1 = ExecutionPayloadV1; // Specify type for execution payload version 1
    type ExecutionPayloadV2 = ExecutionPayloadEnvelopeV2; // Specify type for execution payload version 2
    type ExecutionPayloadV3 = ExecutionPayloadEnvelopeV3; // Specify type for execution payload version 3
    type ExecutionPayloadV4 = ExecutionPayloadEnvelopeV4; // Specify type for execution payload version 4

    // Function to validate version-specific fields
    fn validate_version_specific_fields(
        chain_spec: &ChainSpec, // Chain specification reference
        version: EngineApiMessageVersion, // Engine API version
        payload_or_attrs: PayloadOrAttributes<'_, EthPayloadAttributes>, // Payload or attributes reference
    ) -> Result<(), EngineObjectValidationError> { // Result indicating validation success or error
        validate_version_specific_fields(chain_spec, version, payload_or_attrs) // Call external validation function
    }
}
