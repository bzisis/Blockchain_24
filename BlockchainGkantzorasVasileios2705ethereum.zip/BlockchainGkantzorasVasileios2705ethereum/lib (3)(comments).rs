//! Standalone crate for ethereum-specific Reth configuration and builder types.

// HTML documentation attributes
#![doc(
    html_logo_url = "https://raw.githubusercontent.com/paradigmxyz/reth/main/assets/reth-docs.png",
    html_favicon_url = "https://avatars0.githubusercontent.com/u/97369466?s=256",
    issue_tracker_base_url = "https://github.com/paradigmxyz/reth/issues/"
)]

// Conditionally warn unused crate dependencies except in tests
#![cfg_attr(not(test), warn(unused_crate_dependencies))]

// Conditionally enable features for documentation
#![cfg_attr(docsrs, feature(doc_cfg, doc_auto_cfg))]

// Publicly re-export `EthEngineTypes` from `reth_ethereum_engine_primitives`
pub use reth_ethereum_engine_primitives::EthEngineTypes;

// Module declaration for `evm`
pub mod evm;
// Re-export symbols from `evm` module
pub use evm::{EthEvmConfig, EthExecutorProvider};

// Module declaration for `node`
pub mod node;
// Re-export `EthereumNode` from `node` module
pub use node::EthereumNode;
