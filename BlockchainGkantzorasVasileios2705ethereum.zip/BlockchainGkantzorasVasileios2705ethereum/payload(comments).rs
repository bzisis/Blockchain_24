use alloy_rlp::Encodable;
use reth_chainspec::ChainSpec;
use reth_evm_ethereum::revm_spec_by_timestamp_after_merge;
use reth_payload_primitives::{BuiltPayload, PayloadBuilderAttributes};
use reth_primitives::{
    constants::EIP1559_INITIAL_BASE_FEE, Address, BlobTransactionSidecar, EthereumHardfork, Header,
    SealedBlock, Withdrawals, B256, U256,
};
use reth_rpc_types::engine::{
    ExecutionPayloadEnvelopeV2, ExecutionPayloadEnvelopeV3, ExecutionPayloadEnvelopeV4,
    ExecutionPayloadV1, PayloadAttributes, PayloadId,
};
use reth_rpc_types_compat::engine::payload::{
    block_to_payload_v1, block_to_payload_v3, block_to_payload_v4,
    convert_block_to_payload_field_v2,
};
use revm_primitives::{BlobExcessGasAndPrice, BlockEnv, CfgEnv, CfgEnvWithHandlerCfg, SpecId};
use std::convert::Infallible;

/// Represents a built Ethereum payload containing a sealed block and related metadata.
#[derive(Debug, Clone)]
pub struct EthBuiltPayload {
    /// Identifier of the payload
    pub(crate) id: PayloadId,
    /// The built block
    pub(crate) block: SealedBlock,
    /// The fees of the block
    pub(crate) fees: U256,
    /// The blobs, proofs, and commitments in the block. If the block is pre-cancun, this will be empty.
    pub(crate) sidecars: Vec<BlobTransactionSidecar>,
}

// Implementations for EthBuiltPayload

impl EthBuiltPayload {
    /// Initializes the payload with the given initial block.
    pub const fn new(id: PayloadId, block: SealedBlock, fees: U256) -> Self {
        Self { id, block, fees, sidecars: Vec::new() }
    }

    /// Returns the identifier of the payload.
    pub const fn id(&self) -> PayloadId {
        self.id
    }

    /// Returns the built block (sealed).
    pub const fn block(&self) -> &SealedBlock {
        &self.block
    }

    /// Returns the fees of the block.
    pub const fn fees(&self) -> U256 {
        self.fees
    }

    /// Returns the blob sidecars.
    pub fn sidecars(&self) -> &[BlobTransactionSidecar] {
        &self.sidecars
    }

    /// Adds sidecars to the payload.
    pub fn extend_sidecars(&mut self, sidecars: Vec<BlobTransactionSidecar>) {
        self.sidecars.extend(sidecars)
    }
}

// Implement BuiltPayload trait for EthBuiltPayload
impl BuiltPayload for EthBuiltPayload {
    fn block(&self) -> &SealedBlock {
        &self.block
    }

    fn fees(&self) -> U256 {
        self.fees
    }
}

// Implement BuiltPayload trait for a reference to EthBuiltPayload
impl<'a> BuiltPayload for &'a EthBuiltPayload {
    fn block(&self) -> &SealedBlock {
        (**self).block()
    }

    fn fees(&self) -> U256 {
        (**self).fees()
    }
}

// Conversion to ExecutionPayloadV1 for EthBuiltPayload
impl From<EthBuiltPayload> for ExecutionPayloadV1 {
    fn from(value: EthBuiltPayload) -> Self {
        block_to_payload_v1(value.block)
    }
}

// Conversion to ExecutionPayloadEnvelopeV2 for EthBuiltPayload
impl From<EthBuiltPayload> for ExecutionPayloadEnvelopeV2 {
    fn from(value: EthBuiltPayload) -> Self {
        let EthBuiltPayload { block, fees, .. } = value;

        Self {
            block_value: fees,
            execution_payload: convert_block_to_payload_field_v2(block),
        }
    }
}

// Conversion to ExecutionPayloadEnvelopeV3 for EthBuiltPayload
impl From<EthBuiltPayload> for ExecutionPayloadEnvelopeV3 {
    fn from(value: EthBuiltPayload) -> Self {
        let EthBuiltPayload { block, fees, sidecars, .. } = value;

        Self {
            execution_payload: block_to_payload_v3(block).0,
            block_value: fees,
            should_override_builder: false, // According to spec, set to false if no heuristics
            blobs_bundle: sidecars.into_iter().map(Into::into).collect::<Vec<_>>().into(),
        }
    }
}

// Conversion to ExecutionPayloadEnvelopeV4 for EthBuiltPayload
impl From<EthBuiltPayload> for ExecutionPayloadEnvelopeV4 {
    fn from(value: EthBuiltPayload) -> Self {
        let EthBuiltPayload { block, fees, sidecars, .. } = value;

        Self {
            execution_payload: block_to_payload_v4(block),
            block_value: fees,
            should_override_builder: false, // According to spec, set to false if no heuristics
            blobs_bundle: sidecars.into_iter().map(Into::into).collect::<Vec<_>>().into(),
        }
    }
}

/// Container type for all components required to build a payload.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct EthPayloadBuilderAttributes {
    /// Id of the payload
    pub id: PayloadId,
    /// Parent block to build the payload on top
    pub parent: B256,
    /// Unix timestamp for the generated payload
    pub timestamp: u64,
    /// Address of the recipient for collecting transaction fee
    pub suggested_fee_recipient: Address,
    /// Randomness value for the generated payload
    pub prev_randao: B256,
    /// Withdrawals for the generated payload
    pub withdrawals: Withdrawals,
    /// Root of the parent beacon block
    pub parent_beacon_block_root: Option<B256>,
}

// Implementations for EthPayloadBuilderAttributes

impl EthPayloadBuilderAttributes {
    /// Returns the identifier of the payload.
    pub const fn payload_id(&self) -> PayloadId {
        self.id
    }

    /// Creates a new payload builder for the given parent block and attributes.
    pub fn new(parent: B256, attributes: PayloadAttributes) -> Self {
        let id = payload_id(&parent, &attributes);

        Self {
            id,
            parent,
            timestamp: attributes.timestamp,
            suggested_fee_recipient: attributes.suggested_fee_recipient,
            prev_randao: attributes.prev_randao,
            withdrawals: attributes.withdrawals.unwrap_or_default().into(),
            parent_beacon_block_root: attributes.parent_beacon_block_root,
        }
    }
}

// Implement PayloadBuilderAttributes trait for EthPayloadBuilderAttributes
impl PayloadBuilderAttributes for EthPayloadBuilderAttributes {
    type RpcPayloadAttributes = PayloadAttributes;
    type Error = Infallible;

    /// Creates a new payload builder for the given parent block and attributes.
    fn try_new(parent: B256, attributes: PayloadAttributes) -> Result<Self, Infallible> {
        Ok(Self::new(parent, attributes))
    }

    fn payload_id(&self) -> PayloadId {
        self.id
    }

    fn parent(&self) -> B256 {
        self.parent
    }

    fn timestamp(&self) -> u64 {
        self.timestamp
    }

    fn parent_beacon_block_root(&self) -> Option<B256> {
        self.parent_beacon_block_root
    }

    fn suggested_fee_recipient(&self) -> Address {
        self.suggested_fee_recipient
    }

    fn prev_randao(&self) -> B256 {
        self.prev_randao
    }

    fn withdrawals(&self) -> &Withdrawals {
        &self.withdrawals
    }

    fn cfg_and_block_env(
        &self,
        chain_spec: &ChainSpec,
        parent: &Header,
    ) -> (CfgEnvWithHandlerCfg, BlockEnv) {
        // Configure EVM environment based on parent block
        let cfg = CfgEnv::default().with_chain_id(chain_spec.chain().id());

        // Determine the spec ID based on the timestamp
        let spec_id = revm_spec_by_timestamp_after_merge(chain_spec, self.timestamp());

        // Set blob excess gas based on parent block's state
        let blob_excess_gas_and_price = parent
            .next_block_excess_blob_gas()
            .or_else(|| {
                if spec_id == SpecId::CANCUN {
                    Some(0) // Default excess blob gas if pre-Cancun
                } else {
                    None
                }
            })
            .map(BlobExcessGasAndPrice::new);

        let mut basefee =
            parent.next_block_base_fee(chain_spec.base_fee_params_at_timestamp(self.timestamp()));

        let mut gas_limit = U256::from(parent.gas_limit);

        // Handle London fork gas limit adjustment
        if chain_spec.fork(EthereumHardfork::London).transitions_at_block(parent.number + 1) {
            let elasticity_multiplier =
                chain_spec.base_fee_params_at_timestamp(self.timestamp()).elasticity_multiplier;

            gas_limit *= U256::from(elasticity_multiplier); // Adjust gas limit

            basefee = Some(EIP1559_INITIAL_BASE_FEE); // Set base fee to EIP-1559 initial base fee
        }

        let block_env = BlockEnv {
            number: U256::from(parent.number + 1),
            coinbase: self.suggested_fee_recipient(),
            timestamp: U256::from(self.timestamp()),
            difficulty: U256::ZERO,
            prevrandao: Some(self.prev_randao()),
            gas_limit,
            basefee: basefee.map(U256::from).unwrap_or_default(),
            blob_excess_gas_and_price,
        };

        (CfgEnvWithHandlerCfg::new_with_spec_id(cfg, spec_id), block_env)
        
        
        
        /// Generates the payload id for the configured payload from the [`PayloadAttributes`].
        ///
        /// Returns an 8-byte identifier by hashing the payload components with sha256 hash.
        pub(crate) fn payload_id(parent: &B256, attributes: &PayloadAttributes) -> PayloadId {
            // Import necessary dependencies
            use sha2::Digest;
        
            // Create a new SHA-256 hasher
            let mut hasher = sha2::Sha256::new();
        
            // Hash the parent block
            hasher.update(parent.as_slice());
        
            // Hash the timestamp as big-endian bytes
            hasher.update(&attributes.timestamp.to_be_bytes()[..]);
        
            // Hash the previous RANDAO value
            hasher.update(attributes.prev_randao.as_slice());
        
            // Hash the suggested fee recipient address
            hasher.update(attributes.suggested_fee_recipient.as_slice());
        
            // If there are withdrawals, hash their encoded form
            if let Some(withdrawals) = &attributes.withdrawals {
                let mut buf = Vec::new();
                withdrawals.encode(&mut buf); // Encode withdrawals into buffer
                hasher.update(buf); // Hash the encoded withdrawals
            }
        
            // If there is a parent beacon block root, hash it
            if let Some(parent_beacon_block) = attributes.parent_beacon_block_root {
                hasher.update(parent_beacon_block); // Hash the parent beacon block root
            }
        
            // Finalize the hash and extract the first 8 bytes as a payload identifier
            let out = hasher.finalize();
            PayloadId::new(out.as_slice()[..8].try_into().expect("sufficient length"))
        }
        
        #[cfg(test)]
        mod tests {
            use super::*;
            use reth_primitives::Genesis;
        
            #[test]
            fn ensure_first_london_block_base_fee_is_set() {
                // Example hive_london JSON configuration
                let hive_london = r#" ... "londonBlock": 1, ... "#;
        
                // Example attributes JSON for payload configuration
                let attributes = r#"{"timestamp":"0x1235","prevRandao":"...","suggestedFeeRecipient":"...","withdrawals":null,"parentBeaconBlockRoot":null}"#;
                let attributes: PayloadAttributes = serde_json::from_str(attributes).unwrap();
        
                // Deserialize the Genesis block from hive_london JSON
                let genesis: Genesis = serde_json::from_str(hive_london).unwrap();
        
                // Create ChainSpec from Genesis block
                let chainspec = ChainSpec::from(genesis);
        
                // Create payload builder attributes from chainspec and attributes
                let payload_builder_attributes =
                    EthPayloadBuilderAttributes::new(chainspec.genesis_hash(), attributes);
        
                // Obtain configuration and block environment using cfg_and_block_env method
                let cfg_and_block_env =
                    payload_builder_attributes.cfg_and_block_env(&chainspec, &chainspec.genesis_header());
        
                // Ensure the base fee is set to EIP-1559 initial base fee
                assert_eq!(cfg_and_block_env.1.basefee, U256::from(EIP1559_INITIAL_BASE_FEE));
        
                // Ensure the gas limit is double the previous block's gas limit
                assert_eq!(
                    cfg_and_block_env.1.gas_limit,
                    U256::from(chainspec.genesis_header().gas_limit * 2)
                );
            }
        }
        