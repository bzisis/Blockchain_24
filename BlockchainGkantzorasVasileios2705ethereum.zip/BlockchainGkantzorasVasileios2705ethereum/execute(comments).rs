//! Ethereum block executor.

// Importing necessary crates and modules
use crate::{
    dao_fork::{DAO_HARDFORK_BENEFICIARY, DAO_HARDKFORK_ACCOUNTS},
    EthEvmConfig,
};
use reth_chainspec::{ChainSpec, EthereumHardforks, MAINNET};
use reth_ethereum_consensus::validate_block_post_execution;
use reth_evm::{
    execute::{
        BatchExecutor, BlockExecutionError, BlockExecutionInput, BlockExecutionOutput,
        BlockExecutorProvider, BlockValidationError, Executor, ProviderError,
    },
    ConfigureEvm,
};
use reth_execution_types::ExecutionOutcome;
use reth_primitives::{
    BlockNumber, BlockWithSenders, EthereumHardfork, Header, Receipt, Request, U256,
};
use reth_prune_types::PruneModes;
use reth_revm::{
    batch::{BlockBatchRecord, BlockExecutorStats},
    db::states::bundle_state::BundleRetention,
    state_change::{
        apply_beacon_root_contract_call, apply_blockhashes_update,
        apply_withdrawal_requests_contract_call, post_block_balance_increments,
    },
    Evm, State,
};
use revm_primitives::{
    db::{Database, DatabaseCommit},
    BlockEnv, CfgEnvWithHandlerCfg, EVMError, EnvWithHandlerCfg, ResultAndState,
};

#[cfg(feature = "std")]
use std::{fmt::Display, sync::Arc, vec, vec::Vec};

/// Provides executors to execute regular ethereum blocks
#[derive(Debug, Clone)]
pub struct EthExecutorProvider<EvmConfig = EthEvmConfig> {
    chain_spec: Arc<ChainSpec>,
    evm_config: EvmConfig,
}

impl EthExecutorProvider {
    /// Creates a new default ethereum executor provider.
    pub fn ethereum(chain_spec: Arc<ChainSpec>) -> Self {
        Self::new(chain_spec, Default::default())
    }

    /// Returns a new provider for the mainnet.
    pub fn mainnet() -> Self {
        Self::ethereum(MAINNET.clone())
    }
}

impl<EvmConfig> EthExecutorProvider<EvmConfig> {
    /// Creates a new executor provider.
    pub const fn new(chain_spec: Arc<ChainSpec>, evm_config: EvmConfig) -> Self {
        Self { chain_spec, evm_config }
    }
}

impl<EvmConfig> EthExecutorProvider<EvmConfig>
where
    EvmConfig: ConfigureEvm,
{
    /// Constructs an Ethereum block executor.
    fn eth_executor<DB>(&self, db: DB) -> EthBlockExecutor<EvmConfig, DB>
    where
        DB: Database<Error: Into<ProviderError>>,
    {
        EthBlockExecutor::new(
            self.chain_spec.clone(),
            self.evm_config.clone(),
            // Sets up the EVM state with the provided database.
            State::builder().with_database(db).with_bundle_update().without_state_clear().build(),
        )
    }
}

impl<EvmConfig> BlockExecutorProvider for EthExecutorProvider<EvmConfig>
where
    EvmConfig: ConfigureEvm,
{
    type Executor<DB: Database<Error: Into<ProviderError> + Display>> =
        EthBlockExecutor<EvmConfig, DB>;

    type BatchExecutor<DB: Database<Error: Into<ProviderError> + Display>> =
        EthBatchExecutor<EvmConfig, DB>;

    fn executor<DB>(&self, db: DB) -> Self::Executor<DB>
    where
        DB: Database<Error: Into<ProviderError> + Display>,
    {
        self.eth_executor(db)
    }

    fn batch_executor<DB>(&self, db: DB, prune_modes: PruneModes) -> Self::BatchExecutor<DB>
    where
        DB: Database<Error: Into<ProviderError> + Display>,
    {
        let executor = self.eth_executor(db);
        EthBatchExecutor {
            executor,
            batch_record: BlockBatchRecord::new(prune_modes),
            stats: BlockExecutorStats::default(),
        }
    }
}

/// Helper type for the output of executing a block.
#[derive(Debug, Clone)]
struct EthExecuteOutput {
    receipts: Vec<Receipt>,  // Stores receipts of executed transactions
    requests: Vec<Request>,  // Stores EIP-7685 requests
    gas_used: u64,           // Total gas used in block execution
}

/// Helper container type for EVM with chain spec.
#[derive(Debug, Clone)]
struct EthEvmExecutor<EvmConfig> {
    chain_spec: Arc<ChainSpec>,  // The chain specification
    evm_config: EvmConfig,       // EVM configuration
}

impl<EvmConfig> EthEvmExecutor<EvmConfig>
where
    EvmConfig: ConfigureEvm,
{
    /// Executes the transactions in the block and returns the receipts of the transactions in the
    /// block, the total gas used and the list of EIP-7685 [requests](Request).
    ///
    /// This applies the pre-execution and post-execution changes that require an [EVM](Evm), and
    /// executes the transactions.
    ///
    /// # Note
    ///
    /// It does __not__ apply post-execution changes that do not require an [EVM](Evm), for that see
    /// [`EthBlockExecutor::post_execution`].
    fn execute_state_transitions<Ext, DB>(
        &self,
        block: &BlockWithSenders,
        mut evm: Evm<'_, Ext, &mut State<DB>>,
    ) -> Result<EthExecuteOutput, BlockExecutionError>
    where
        DB: Database,
        DB::Error: Into<ProviderError> + std::fmt::Display,
    {
        // apply pre execution changes
        apply_beacon_root_contract_call(
            &self.chain_spec,
            block.timestamp,
            block.number,
            block.parent_beacon_block_root,
            &mut evm,
        )?;
        apply_blockhashes_update(
            evm.db_mut(),
            &self.chain_spec,
            block.timestamp,
            block.number,
            block.parent_hash,
        )?;

        // execute transactions
        let mut cumulative_gas_used = 0;
        let mut receipts = Vec::with_capacity(block.body.len());
        for (sender, transaction) in block.transactions_with_sender() {
            // The sum of the transaction’s gas limit, Tg, and the gas utilized in this block prior,
            // must be no greater than the block’s gasLimit.
            let block_available_gas = block.header.gas_limit - cumulative_gas_used;
            if transaction.gas_limit() > block_available_gas {
                return Err(BlockValidationError::TransactionGasLimitMoreThanAvailableBlockGas {
                    transaction_gas_limit: transaction.gas_limit(),
                    block_available_gas,
                }
                .into())
            }

            self.evm_config.fill_tx_env(evm.tx_mut(), transaction, *sender);

            // Execute transaction.
            let ResultAndState { result, state } = evm.transact().map_err(move |err| {
                let new_err = match err {
                    EVMError::Transaction(e) => EVMError::Transaction(e),
                    EVMError::Header(e) => EVMError::Header(e),
                    EVMError::Database(e) => EVMError::Database(e.into()),
                    EVMError::Custom(e) => EVMError::Custom(e),
                    EVMError::Precompile(e) => EVMError::Precompile(e),
                };
                // Ensure hash is calculated for error log, if not already done
                BlockValidationError::EVM {
                    hash: transaction.recalculate_hash(),
                    error: Box::new(new_err),
                }
            })?;
            evm.db_mut().commit(state);

            // append gas used
            cumulative_gas_used += result.gas_used();

            // Push transaction changeset and calculate header bloom filter for receipt.
            receipts.push(
                #[allow(clippy::needless_update)] // side-effect of optimism fields
                Receipt {
                    tx_type: transaction.tx_type(),
                    // Success flag was added in `EIP-658: Embedding transaction status code in
                    // receipts`.
                    success: result.is_success(),
                    cumulative_gas_used,
                    // convert to reth log
                    logs: result.into_logs(),
                    ..Default::default()
                },
            );
        }

        let requests = if self.chain_spec.is_prague_active_at_timestamp(block.timestamp) {
            // Collect all EIP-6110 deposits
            let deposit_requests =
                crate::eip6110::parse_deposits_from_receipts(&self.chain_spec, &receipts)?;

            // Collect all EIP-7685 requests
            let withdrawal_requests = apply_withdrawal_requests_contract_call(&mut evm)?;

            [deposit_requests, withdrawal_requests].concat()
        } else {
            vec![]
        };

        Ok(EthExecuteOutput { receipts, requests, gas_used: cumulative_gas_used })
    }
}

/// A basic Ethereum block executor.
///
/// Expected usage:
/// - Create a new instance of the executor.
/// - Execute the block.
#[derive(Debug)]
pub struct EthBlockExecutor<EvmConfig, DB> {
    executor: EthEvmExecutor<EvmConfig>,  // Chain specific EVM executor
    state: State<DB>,                     // State to use for execution
}

impl<EvmConfig, DB> EthBlockExecutor<EvmConfig, DB> {
    /// Creates a new Ethereum block executor.
    pub const fn new(chain_spec: Arc<ChainSpec>, evm_config: EvmConfig, state: State<DB>) -> Self {
        Self { executor: EthEvmExecutor { chain_spec, evm_config }, state }
    }

    #[inline]
    fn chain_spec(&self) -> &ChainSpec {
        &self.executor.chain_spec
    }

    /// Returns mutable reference to the state that wraps the underlying database.
    #[allow(unused)]
    fn state_mut(&mut self) -> &mut State<DB> {
        &mut self.state
    }
}

impl<EvmConfig, DB> EthBlockExecutor<EvmConfig, DB>
where
    EvmConfig: ConfigureEvm,
    DB: Database<Error: Into<ProviderError> + Display>,
{
    /// Configures a new evm configuration and block environment for the given block.
    ///
    /// # Caution
    ///
    /// This does not initialize the tx environment.
    fn evm_env_for_block(&self, header: &Header, total_difficulty: U256) -> EnvWithHandlerCfg {
        let mut cfg = CfgEnvWithHandlerCfg::new(Default::default(), Default::default());
        let mut block_env = BlockEnv::default();
        EvmConfig::fill_cfg_and_block_env(
            &mut cfg,
            &mut block_env,
            self.chain_spec(),
            header,
            total_difficulty,
        );

        EnvWithHandlerCfg::new_with_cfg_env(cfg, block_env, Default::default())
    }

    /// Execute a single block and apply the state changes to the internal state.
    ///
    /// Returns the receipts of the transactions in the block, the total gas used and the list of
    /// EIP-7685 [requests](Request).
    ///
    /// Returns an error if execution fails.
    fn execute_without_verification(
        &mut self,
        block: &BlockWithSenders,
        total_difficulty: U256,
    ) -> Result<EthExecuteOutput, BlockExecutionError> {
        // 1. prepare state on new block
        self.on_new_block(&block.header);

        // 2. configure the evm and execute
        let env = self.evm_env_for_block(&block.header, total_difficulty);
        let output = {
            let evm = self.executor.evm_config.evm_with_env(&mut self.state, env);
            self.executor.execute_state_transitions(block, evm)
        }?;

        // 3. apply post execution changes
        self.post_execution(block, total_difficulty)?;

        Ok(output)
    }

    /// Apply settings before a new block is executed.
    pub(crate) fn on_new_block(&mut self, header: &Header) {
        // Set state clear flag if the block is after the Spurious Dragon hardfork.
        let state_clear_flag = self.chain_spec().is_spurious_dragon_active_at_block(header.number);
        self.state.set_state_clear_flag(state_clear_flag);
    }

    /// Apply post execution state changes that do not require an [EVM](Evm), such as: block
    /// rewards, withdrawals, and irregular DAO hardfork state change
    pub fn post_execution(
        &mut self,
        block: &BlockWithSenders,
        total_difficulty: U256,
    ) -> Result<(), BlockExecutionError> {
        let mut balance_increments =
            post_block_balance_increments(self.chain_spec(), block, total_difficulty);

        // Irregular state change at Ethereum DAO hardfork
        if self.chain_spec().fork(EthereumHardfork::Dao).transitions_at_block(block.number) {
            // drain balances from hardcoded addresses.
            let drained_balance: u128 = self
                .state
                .drain_balances(DAO_HARDKFORK_ACCOUNTS)
                .map_err(|_| BlockValidationError::IncrementBalanceFailed)?
                .into_iter()
                .sum();

            // return balance to DAO beneficiary.
            *balance_increments.entry(DAO_HARDFORK_BENEFICIARY).or_default() += drained_balance;
        }
        // increment balances
        self.state
            .increment_balances(balance_increments)
            .map_err(|_| BlockValidationError::IncrementBalanceFailed)?;

        Ok(())
    }
}

impl<EvmConfig, DB> Executor<DB> for EthBlockExecutor<EvmConfig, DB>
where
    EvmConfig: ConfigureEvm,
    DB: Database<Error: Into<ProviderError> + Display>,
{
    type Input<'a> = BlockExecutionInput<'a, BlockWithSenders>;
    type Output = BlockExecutionOutput<Receipt>;
    type Error = BlockExecutionError;

    /// Executes the block and commits the state changes.
    ///
    /// Returns the receipts of the transactions in the block.
    ///
    /// Returns an error if the block could not be executed or failed verification.
    ///
    /// State changes are committed to the database.
    fn execute(mut self, input: Self::Input<'_>) -> Result<Self::Output, Self::Error> {
        let BlockExecutionInput { block, total_difficulty } = input;
        let EthExecuteOutput { receipts, requests, gas_used } =
            self.execute_without_verification(block, total_difficulty)?;

        // Merges the state transitions into the bundle, keeping reverts for bundle retention.
        self.state.merge_transitions(BundleRetention::Reverts);

        Ok(BlockExecutionOutput { state: self.state.take_bundle(), receipts, requests, gas_used })
    }
}

/// An executor for a batch of blocks.
///
/// State changes are tracked until the executor is finalized.
#[derive(Debug)]
pub struct EthBatchExecutor<EvmConfig, DB> {
    executor: EthBlockExecutor<EvmConfig, DB>,  // Executor used for executing single blocks
    batch_record: BlockBatchRecord,            // Keeps track of batch and records receipts based on prune mode
    stats: BlockExecutorStats,                 // Statistics for the batch executor
}

impl<EvmConfig, DB> EthBatchExecutor<EvmConfig, DB> {
    /// Returns mutable reference to the state that wraps the underlying database.
    #[allow(unused)]
    fn state_mut(&mut self) -> &mut State<DB> {
        self.executor.state_mut()
    }
}

impl<EvmConfig, DB> BatchExecutor<DB> for EthBatchExecutor<EvmConfig, DB>
where
    EvmConfig: ConfigureEvm,
    DB: Database<Error: Into<ProviderError> + Display>,
{
    type Input<'a> = BlockExecutionInput<'a, BlockWithSenders>;
    type Output = ExecutionOutcome;
    type Error = BlockExecutionError;

    /// Executes and verifies a single block within the batch.
    ///
    /// Ensures all state changes are consistent and compliant with configured prune modes.
    fn execute_and_verify_one(&mut self, input: Self::Input<'_>) -> Result<(), Self::Error> {
        let BlockExecutionInput { block, total_difficulty } = input;
        let EthExecuteOutput { receipts, requests, gas_used: _ } =
            self.executor.execute_without_verification(block, total_difficulty)?;

        // Validates the block's post-execution status using the receipts and requests.
        validate_block_post_execution(block, self.executor.chain_spec(), &receipts, &requests)?;

        // Prepares the state according to the prune mode specified.
        let retention = self.batch_record.bundle_retention(block.number);
        self.executor.state.merge_transitions(retention);

        // Stores receipts in the batch record.
        self.batch_record.save_receipts(receipts)?;

        // Stores requests in the batch record.
        self.batch_record.save_requests(requests);

        // Sets the first block number if not already set.
        if self.batch_record.first_block().is_none() {
            self.batch_record.set_first_block(block.number);
        }

        Ok(())
    }

    /// Finalizes the batch executor, returning the overall execution outcome.
    ///
    /// Finalizes the state and associated statistics for reporting.
    fn finalize(mut self) -> Self::Output {
        self.stats.log_debug();

        ExecutionOutcome::new(
            self.executor.state.take_bundle(),
            self.batch_record.take_receipts(),
            self.batch_record.first_block().unwrap_or_default(),
            self.batch_record.take_requests(),
        )
    }

    /// Sets the current tip block number for the batch executor.
    ///
    /// Useful for managing batch execution across multiple blocks.
    fn set_tip(&mut self, tip: BlockNumber) {
        self.batch_record.set_tip(tip);
    }

    /// Provides a hint regarding the size of the executor's state.
    ///
    /// Useful for optimizing memory management and resource allocation.
    fn size_hint(&self) -> Option<usize> {
        Some(self.executor.state.bundle_state.size_hint())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use alloy_eips::{
        eip2935::HISTORY_STORAGE_ADDRESS,
        eip4788::{BEACON_ROOTS_ADDRESS, BEACON_ROOTS_CODE, SYSTEM_ADDRESS},
        eip7002::{WITHDRAWAL_REQUEST_PREDEPLOY_ADDRESS, WITHDRAWAL_REQUEST_PREDEPLOY_CODE},
    };
    use reth_chainspec::{ChainSpecBuilder, ForkCondition};
    use reth_primitives::{
        constants::{EMPTY_ROOT_HASH, ETH_TO_WEI},
        keccak256, public_key_to_address, Account, Block, Transaction, TxKind, TxLegacy, B256,
    };
    use reth_revm::{
        database::StateProviderDatabase, test_utils::StateProviderTest, TransitionState,
    };
    use reth_testing_utils::generators::{self, sign_tx_with_key_pair};
    use revm_primitives::{b256, fixed_bytes, Bytes, BLOCKHASH_SERVE_WINDOW};
    use secp256k1::{Keypair, Secp256k1};
    use std::collections::HashMap;

    // Example test function
    fn create_state_provider_with_beacon_root_contract() -> StateProviderTest {
        let mut db = StateProviderTest::default();

        let beacon_root_contract_account = Account {
            balance: U256::ZERO,
            bytecode_hash: Some(keccak256(BEACON_ROOTS_CODE.clone())),
            nonce: 1,
        };

        db.insert_account(
            BEACON_ROOTS_ADDRESS,
            beacon_root_contract_account,
            Some(BEACON_ROOTS_CODE.clone()),
            HashMap::new(),
        );

        db
    }

    fn create_state_provider_with_withdrawal_requests_contract() -> StateProviderTest {
        // Initialize a test state provider database.
        let mut db = StateProviderTest::default();
    
        // Define the account for the withdrawal requests contract.
        let withdrawal_requests_contract_account = Account {
            nonce: 1,
            balance: U256::ZERO,
            bytecode_hash: Some(keccak256(WITHDRAWAL_REQUEST_PREDEPLOY_CODE.clone())),
        };
    
        // Insert the withdrawal requests contract into the database.
        db.insert_account(
            WITHDRAWAL_REQUEST_PREDEPLOY_ADDRESS,
            withdrawal_requests_contract_account,
            Some(WITHDRAWAL_REQUEST_PREDEPLOY_CODE.clone()),
            HashMap::new(),
        );
    
        // Return the populated state provider database.
        db
    }
    
    // Function to create an Ethereum executor provider.
    fn executor_provider(chain_spec: Arc<ChainSpec>) -> EthExecutorProvider<EthEvmConfig> {
        EthExecutorProvider {
            chain_spec,
            evm_config: Default::default(),
        }
    }
    
    // Test case for EIP-4788 scenario: non-genesis call.
    #[test]
    fn eip_4788_non_genesis_call() {
        // Initialize a block header.
        let mut header = Header {
            timestamp: 1,
            number: 1,
            excess_blob_gas: Some(0),
            ..Header::default()
        };
    
        // Create a state provider database with a contract.
        let db = create_state_provider_with_withdrawal_requests_contract();
    
        // Define the chain specification with necessary forks.
        let chain_spec = Arc::new(
            ChainSpecBuilder::from(&*MAINNET)
                .shanghai_activated()
                .with_fork(EthereumHardfork::Cancun, ForkCondition::Timestamp(1))
                .build(),
        );
    
        // Create an executor provider based on the chain specification.
        let provider = executor_provider(chain_spec);
    
        // Attempt to execute a block without the parent beacon block root, expecting an error.
        let err = provider
            .executor(StateProviderDatabase::new(&db))
            .execute((
                &BlockWithSenders {
                    block: Block {
                        header: header.clone(),
                        body: vec![],
                        ommers: vec![],
                        withdrawals: None,
                        requests: None,
                    },
                    senders: vec![],
                },
                U256::ZERO,
            ))
            .expect_err("Executing Cancun block without parent beacon block root field should fail");
    
        // Assert that the error corresponds to a missing parent beacon block root.
        assert_eq!(
            err.as_validation().unwrap().clone(),
            BlockValidationError::MissingParentBeaconBlockRoot
        );
    
        // Fix the header by setting a parent beacon block root.
        header.parent_beacon_block_root = Some(B256::with_last_byte(0x69));
    
        // Initialize an executor with the fixed header.
        let mut executor = provider.executor(StateProviderDatabase::new(&db));
    
        // Execute a block with the fixed header and ensure it does not fail.
        executor
            .execute_without_verification(
                &BlockWithSenders {
                    block: Block {
                        header: header.clone(),
                        body: vec![],
                        ommers: vec![],
                        withdrawals: None,
                        requests: None,
                    },
                    senders: vec![],
                },
                U256::ZERO,
            )
            .unwrap();
    
        // Verify the storage values of the contract after execution.
        let history_buffer_length = 8191u64;
        let timestamp_index = header.timestamp % history_buffer_length;
        let parent_beacon_block_root_index =
            timestamp_index % history_buffer_length + history_buffer_length;
    
        // Check storage values for timestamp and parent beacon block root.
        let timestamp_storage =
            executor.state.storage(BEACON_ROOTS_ADDRESS, U256::from(timestamp_index)).unwrap();
        assert_eq!(timestamp_storage, U256::from(header.timestamp));
    
        let parent_beacon_block_root_storage = executor
            .state
            .storage(BEACON_ROOTS_ADDRESS, U256::from(parent_beacon_block_root_index))
            .expect("storage value should exist");
        assert_eq!(parent_beacon_block_root_storage, U256::from(0x69));
    }
    
    // Test case for EIP-4788 scenario: no code at BEACON_ROOTS_ADDRESS during Cancun.
    #[test]
    fn eip_4788_no_code_cancun() {
        // Initialize a block header with specified parameters.
        let header = Header {
            timestamp: 1,
            number: 1,
            parent_beacon_block_root: Some(B256::with_last_byte(0x69)),
            excess_blob_gas: Some(0),
            ..Header::default()
        };
    
        // Create an empty state provider database.
        let db = StateProviderTest::default();
    
        // Define the chain specification for Cancun fork.
        let chain_spec = Arc::new(
            ChainSpecBuilder::from(&*MAINNET)
                .shanghai_activated()
                .with_fork(EthereumHardfork::Cancun, ForkCondition::Timestamp(1))
                .build(),
        );
    
        // Create an executor provider based on the chain specification.
        let provider = executor_provider(chain_spec);
    
        // Attempt to execute an empty block with a parent beacon block root, expecting success.
        provider
            .batch_executor(StateProviderDatabase::new(&db), PruneModes::none())
            .execute_and_verify_one((
                &BlockWithSenders {
                    block: Block {
                        header,
                        body: vec![],
                        ommers: vec![],
                        withdrawals: None,
                        requests: None,
                    },
                    senders: vec![],
                },
                U256::ZERO,
            ))
            .expect("Executing a block with no transactions while Cancun is active should not fail");
    }
    
    // Test case for EIP-4788 scenario: empty account call with Cancun.
    #[test]
    fn eip_4788_empty_account_call() {
        // Create a state provider database with a contract.
        let mut db = create_state_provider_with_withdrawal_requests_contract();
    
        // Insert an empty account at SYSTEM_ADDRESS.
        db.insert_account(SYSTEM_ADDRESS, Account::default(), None, HashMap::new());
    
        // Define the chain specification for Cancun fork.
        let chain_spec = Arc::new(
            ChainSpecBuilder::from(&*MAINNET)
                .shanghai_activated()
                .with_fork(EthereumHardfork::Cancun, ForkCondition::Timestamp(1))
                .build(),
        );
    
        // Create an executor provider based on the chain specification.
        let provider = executor_provider(chain_spec);
    
        // Construct the header for block one.
        let header = Header {
            timestamp: 1,
            number: 1,
            parent_beacon_block_root: Some(B256::with_last_byte(0x69)),
            excess_blob_gas: Some(0),
            ..Header::default()
        };
    
        // Initialize a batch executor with pruning disabled.
        let mut executor = provider.batch_executor(StateProviderDatabase::new(&db), PruneModes::none());
    
        // Attempt to execute an empty block with a parent beacon block root, expecting success.
        executor
            .execute_and_verify_one((
                &BlockWithSenders {
                    block: Block {
                        header,
                        body: vec![],
                        ommers: vec![],
                        withdrawals: None,
                        requests: None,
                    },
                    senders: vec![],
                },
                U256::ZERO,
            ))
            .expect("Executing a block with no transactions while Cancun is active should not fail");
    
        // Ensure that the nonce of the SYSTEM_ADDRESS account has not changed.
        let nonce = executor
            .state_mut()
            .basic(SYSTEM_ADDRESS)
            .unwrap()
            .unwrap()
            .nonce;
        assert_eq!(nonce, 0);
    }
    
    // Test case for EIP-4788 scenario: genesis call with Cancun.
    #[test]
    fn eip_4788_genesis_call() {
        // Create a state provider database with a contract.
        let db = create_state_provider_with_withdrawal_requests_contract();
    
        // Define the chain specification for Cancun fork at genesis.
        let chain_spec = Arc::new(
            ChainSpecBuilder::from(&*MAINNET)
                .shanghai_activated()
                .with_fork(EthereumHardfork::Cancun, ForkCondition::Timestamp(0))
                .build(),
        );
    
        // Retrieve the genesis header from the chain specification.
        let mut header = chain_spec.genesis_header();
    
        // Create an executor provider based on the chain specification.
        let provider = executor_provider(chain_spec);
    
        // Initialize a batch executor with pruning disabled.
        let mut executor = provider.batch_executor(StateProviderDatabase::new(&db), PruneModes::none());
    
        // Attempt to execute the genesis block with a non-zero parent beacon block root, expecting an error.
        header.parent_beacon_block_root = Some(B256::with_last_byte(0x69));
        let _err = executor
            .execute_and_verify_one((
                &BlockWithSenders {
                    block: Block {
                        header: header.clone(),
                        body: vec![],
                        ommers: vec![],
                        withdrawals: None,
                        requests: None,
                    },
                    senders: vec![],
                },
                U256::ZERO,
            ))
            .expect_err("Executing genesis Cancun block with non-zero parent beacon block root field should fail");
    }
// Fix the parent beacon block root in the header
header.parent_beacon_block_root = Some(B256::ZERO);

// Execute and verify the genesis block without triggering a system contract call
executor
    .execute_and_verify_one((
        &BlockWithSenders {
            block: Block {
                header,
                body: vec![],
                ommers: vec![],
                withdrawals: None,
                requests: None,
            },
            senders: vec![],
        },
        U256::ZERO,
    )
    .into())
    .unwrap();

// After execution, check that there are no storage changes by examining the transition state
let transition_state = executor
    .state_mut()
    .transition_state
    .take()
    .expect("the evm should be initialized with bundle updates");

// Assert that the transition state is default (empty)
assert_eq!(transition_state, TransitionState::default());
}

#[test]
fn eip_4788_high_base_fee() {
    // Test scenario for EIP-4788: high base fee
    let header = Header {
        timestamp: 1,
        number: 1,
        parent_beacon_block_root: Some(B256::with_last_byte(0x69)),
        base_fee_per_gas: Some(u64::MAX),
        excess_blob_gas: Some(0),
        ..Header::default()
    };

    // Create a database with state provider containing block hashes
    let db = create_state_provider_with_beacon_root_contract();

    // Set up chain specification
    let chain_spec = Arc::new(
        ChainSpecBuilder::from(&*MAINNET)
            .shanghai_activated()
            .with_fork(EthereumHardfork::Cancun, ForkCondition::Timestamp(1))
            .build(),
    );

    // Create an executor provider
    let provider = executor_provider(chain_spec);

    // Initialize batch executor
    let mut executor =
        provider.batch_executor(StateProviderDatabase::new(&db), PruneModes::none());

    // Execute a block with the specified header and ensure it does not fail
    executor
        .execute_and_verify_one((
            &BlockWithSenders {
                block: Block {
                    header: header.clone(),
                    body: vec![],
                    ommers: vec![],
                    withdrawals: None,
                    requests: None,
                },
                senders: vec![],
            },
            U256::ZERO,
        )
        .into())
        .unwrap();

    // Check storage after execution:
    // - Storage value at timestamp % HISTORY_BUFFER_LENGTH should be equal to timestamp
    // - Storage value at timestamp % HISTORY_BUFFER_LENGTH + HISTORY_BUFFER_LENGTH should be equal to parent_beacon_block_root
    let history_buffer_length = 8191u64;
    let timestamp_index = header.timestamp % history_buffer_length;
    let parent_beacon_block_root_index =
        timestamp_index % history_buffer_length + history_buffer_length;

    // Get and assert timestamp storage value
    let timestamp_storage = executor
        .state_mut()
        .storage(BEACON_ROOTS_ADDRESS, U256::from(timestamp_index))
        .unwrap();
    assert_eq!(timestamp_storage, U256::from(header.timestamp));

    // Get and assert parent beacon block root storage value
    let parent_beacon_block_root_storage = executor
        .state_mut()
        .storage(BEACON_ROOTS_ADDRESS, U256::from(parent_beacon_block_root_index))
        .unwrap();
    assert_eq!(parent_beacon_block_root_storage, U256::from(0x69));
}

// Function to create a state provider with block hashes up to a given block number
fn create_state_provider_with_block_hashes(latest_block: u64) -> StateProviderTest {
    let mut db = StateProviderTest::default();
    for block_number in 0..=latest_block {
        db.insert_block_hash(block_number, keccak256(block_number.to_string()));
    }
    db
}

#[test]
fn eip_2935_pre_fork() {
    // Test scenario for EIP-2935: pre-fork activation
    let db = create_state_provider_with_block_hashes(1);

    // Set up chain specification
    let chain_spec = Arc::new(
        ChainSpecBuilder::from(&*MAINNET)
            .shanghai_activated()
            .with_fork(EthereumHardfork::Prague, ForkCondition::Never)
            .build(),
    );

    // Create an executor provider
    let provider = executor_provider(chain_spec);

    // Initialize batch executor
    let mut executor =
        provider.batch_executor(StateProviderDatabase::new(&db), PruneModes::none());

    // Construct the header for block one
    let header = Header { timestamp: 1, number: 1, ..Header::default() };

    // Execute an empty block and ensure it does not fail
    executor
        .execute_and_verify_one((
            &BlockWithSenders {
                block: Block {
                    header,
                    body: vec![],
                    ommers: vec![],
                    withdrawals: None,
                    requests: None,
                },
                senders: vec![],
            },
            U256::ZERO,
        )
        .into())
        .expect("Executing a block with no transactions while Prague is active should not fail");

    // Ensure that the block hash was not written to storage, as this is before the fork activation
    assert!(executor.state_mut().basic(HISTORY_STORAGE_ADDRESS).unwrap().is_none());
    assert!(executor
        .state_mut()
        .storage(HISTORY_STORAGE_ADDRESS, U256::ZERO)
        .unwrap()
        .is_zero());
}

#[test]
fn eip_2935_fork_activation_genesis() {
    // Test scenario for EIP-2935: fork activation at genesis
    let db = create_state_provider_with_block_hashes(0);

    // Set up chain specification
    let chain_spec = Arc::new(
        ChainSpecBuilder::from(&*MAINNET)
            .shanghai_activated()
            .with_fork(EthereumHardfork::Prague, ForkCondition::Timestamp(0))
            .build(),
    );

    // Get the genesis header from chain specification
    let header = chain_spec.genesis_header();

    // Create an executor provider
    let provider = executor_provider(chain_spec);

    // Initialize batch executor
    let mut executor =
        provider.batch_executor(StateProviderDatabase::new(&db), PruneModes::none());

    // Execute the genesis block and ensure it does not fail
    executor
        .execute_and_verify_one((
            &BlockWithSenders {
                block: Block {
                    header,
                    body: vec![],
                    ommers: vec![],
                    withdrawals: None,
                    requests: None,
                },
                senders: vec![],
            },
            U256::ZERO,
        )
        .into())
        .expect("Executing a block with no transactions while Prague is active should not fail");

    // Ensure that the block hash was not written to storage, as there are no blocks preceding genesis
    assert!(executor.state_mut().basic(HISTORY_STORAGE_ADDRESS).unwrap().is_none());
    assert!(executor
        .state_mut()
        .storage(HISTORY_STORAGE_ADDRESS, U256::ZERO)
        .unwrap()
        .is_zero());
}

#[test]
fn eip_2935_fork_activation_within_window_bounds() {
    // Test scenario for EIP-2935: fork activation within window bounds
    let fork_activation_block = (BLOCKHASH_SERVE_WINDOW - 10) as u64;
    let db = create_state_provider_with_block_hashes(fork_activation_block);

    // Set up chain specification
    let chain_spec = Arc::new(
        ChainSpecBuilder::from(&*MAINNET)
            .shanghai_activated()
            .with_fork(EthereumHardfork::Prague, ForkCondition::Timestamp(1))
            .build(),
    );

    // Construct the header for the fork activation block
    let header = Header {
        parent_hash: B256::random(),
        timestamp: 1,
        number: fork_activation_block,
        requests_root: Some(EMPTY_ROOT_HASH),
        ..Header::default()
    };

    // Create an executor provider
    let provider = executor_provider(chain_spec);

    // Initialize batch executor
    let mut executor =
        provider.batch_executor(StateProviderDatabase::new(&db), PruneModes::none());

    // Execute the fork activation block and ensure it does not fail
    executor
        .execute_and_verify_one((
            &BlockWithSenders {
                block: Block {
                    header,
                    body: vec![],
                    ommers: vec![],
                    withdrawals: None,
                    requests: None,
                },
                senders: vec![],
            },
            U256::ZERO,
        )
        .into())
        .expect("Executing a block with no transactions while Prague is active should not fail");

    // Assert that the ancestor hash of the fork activation block is present in storage
    assert!(executor.state_mut().basic(HISTORY_STORAGE_ADDRESS).unwrap().is_some());
    assert_ne!(
        executor
            .state_mut()
            .storage(HISTORY_STORAGE_ADDRESS, U256::from(fork_activation_block - 1))
            .unwrap(),
        U256::ZERO
    );

    // Assert that the hash of the fork activation block itself is not in storage
    assert!(executor
        .state_mut()
        .storage(HISTORY_STORAGE_ADDRESS, U256::from(fork_activation_block))
        .unwrap()
        .is_zero());
}

#[test]
fn eip_2935_fork_activation_outside_window_bounds() {
    // Test scenario for EIP-2935: fork activation outside window bounds
    let fork_activation_block = (BLOCKHASH_SERVE_WINDOW + 256) as u64;
    let db = create_state_provider_with_block_hashes(fork_activation_block);

    // Set up chain specification
    let chain_spec = Arc::new(
        ChainSpecBuilder::from(&*MAINNET)
            .shanghai_activated()
            .with_fork(EthereumHardfork::Prague, ForkCondition::Timestamp(1))
            .build(),
    );

    // Create an executor provider
    let provider = executor_provider(chain_spec);

    // Initialize batch executor
    let mut executor =
        provider.batch_executor(StateProviderDatabase::new(&db), PruneModes::none());

    // Construct the header for the fork activation block
    let header = Header {
        parent_hash: B256::random(),
        timestamp: 1,
        number: fork_activation_block,
        requests_root: Some(EMPTY_ROOT_HASH),
        ..Header::default()
    };

    // Execute the fork activation block and ensure it does not fail
    executor
        .execute_and_verify_one((
            &BlockWithSenders {
                block: Block {
                    header,
                    body: vec![],
                    ommers: vec![],
                    withdrawals: None,
                    requests: None,
                },
                senders: vec![],
            },
            U256::ZERO,
        )
        .into())
        .expect("Executing a block with no transactions while Prague is active should not fail");

        // Test ensuring that the ancestor of the fork activation block hash is present in storage
fn eip_2935_state_transition_inside_fork() {
    // Create a state provider with block hashes up to 2
    let db = create_state_provider_with_block_hashes(2);

    // Define chain specification with Prague fork activated at genesis
    let chain_spec = Arc::new(
        ChainSpecBuilder::from(&*MAINNET)
            .shanghai_activated()
            .with_fork(EthereumHardfork::Prague, ForkCondition::Timestamp(0))
            .build(),
    );

    // Generate the genesis header and compute its hash
    let mut header = chain_spec.genesis_header();
    header.requests_root = Some(EMPTY_ROOT_HASH);
    let header_hash = header.hash_slow();

    // Create an executor provider and initialize a batch executor
    let provider = executor_provider(chain_spec);
    let mut executor = provider.batch_executor(StateProviderDatabase::new(&db), PruneModes::none());

    // Execute the genesis block (block 0)
    executor
        .execute_and_verify_one(
            (
                &BlockWithSenders {
                    block: Block {
                        header,
                        body: vec![],
                        ommers: vec![],
                        withdrawals: None,
                        requests: None,
                    },
                    senders: vec![],
                },
                U256::ZERO,
            )
                .into(),
        )
        .expect(
            "Executing a block with no transactions while Prague is active should not fail",
        );

    // Assert that storage related to history exists only for the genesis block
    assert!(executor.state_mut().basic(HISTORY_STORAGE_ADDRESS).unwrap().is_none());
    assert!(executor
        .state_mut()
        .storage(HISTORY_STORAGE_ADDRESS, U256::ZERO)
        .unwrap()
        .is_zero());

    // Generate header for block 1 and compute its hash
    let header = Header {
        parent_hash: header_hash,
        timestamp: 1,
        number: 1,
        requests_root: Some(EMPTY_ROOT_HASH),
        ..Header::default()
    };
    let header_hash = header.hash_slow();

    // Execute block 1
    executor
        .execute_and_verify_one(
            (
                &BlockWithSenders {
                    block: Block {
                        header,
                        body: vec![],
                        ommers: vec![],
                        withdrawals: None,
                        requests: None,
                    },
                    senders: vec![],
                },
                U256::ZERO,
            )
                .into(),
        )
        .expect(
            "Executing a block with no transactions while Prague is active should not fail",
        );

    // Assert storage contains hash of genesis block but not block 1
    assert!(executor.state_mut().basic(HISTORY_STORAGE_ADDRESS).unwrap().is_some());
    assert_ne!(
        executor.state_mut().storage(HISTORY_STORAGE_ADDRESS, U256::ZERO).unwrap(),
        U256::ZERO
    );
    assert!(executor
        .state_mut()
        .storage(HISTORY_STORAGE_ADDRESS, U256::from(1))
        .unwrap()
        .is_zero());

    // Generate header for block 2 and compute its hash
    let header = Header {
        parent_hash: header_hash,
        timestamp: 1,
        number: 2,
        requests_root: Some(EMPTY_ROOT_HASH),
        ..Header::default()
    };

    // Execute block 2
    executor
        .execute_and_verify_one(
            (
                &BlockWithSenders {
                    block: Block {
                        header,
                        body: vec![],
                        ommers: vec![],
                        withdrawals: None,
                        requests: None,
                    },
                    senders: vec![],
                },
                U256::ZERO,
            )
                .into(),
        )
        .expect(
            "Executing a block with no transactions while Prague is active should not fail",
        );

    // Assert storage contains hashes of genesis and block 1 but not block 2
    assert!(executor.state_mut().basic(HISTORY_STORAGE_ADDRESS).unwrap().is_some());
    assert_ne!(
        executor.state_mut().storage(HISTORY_STORAGE_ADDRESS, U256::ZERO).unwrap(),
        U256::ZERO
    );
    assert_ne!(
        executor.state_mut().storage(HISTORY_STORAGE_ADDRESS, U256::from(1)).unwrap(),
        U256::ZERO
    );
    assert!(executor
        .state_mut()
        .storage(HISTORY_STORAGE_ADDRESS, U256::from(2))
        .unwrap()
        .is_zero());
}

// Test for EIP-7002 functionality
fn eip_7002() {
    // Define chain specification with Prague fork activated
    let chain_spec = Arc::new(
        ChainSpecBuilder::from(&*MAINNET)
            .shanghai_activated()
            .with_fork(EthereumHardfork::Prague, ForkCondition::Timestamp(0))
            .build(),
    );

    // Create state provider with withdrawal requests contract deployed
    let mut db = create_state_provider_with_withdrawal_requests_contract();

    // Initialize Secp256k1 for key pair generation
    let secp = Secp256k1::new();
    // Generate a new key pair for the sender
    let sender_key_pair = Keypair::new(&secp, &mut generators::rng());
    // Get the sender's address from the public key
    let sender_address = public_key_to_address(sender_key_pair.public_key());

    // Insert sender's account into the state with nonce, balance, and bytecode hash
    db.insert_account(
        sender_address,
        Account { nonce: 1, balance: U256::from(ETH_TO_WEI), bytecode_hash: None },
        None,
        HashMap::new(),
    );

    // Define validator public key and withdrawal amount as fixed bytes
    let validator_public_key =
        fixed_bytes!("111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111");
    let withdrawal_amount = fixed_bytes!("2222222222222222");
    // Concatenate validator public key and withdrawal amount into input bytes
    let input: Bytes = [&validator_public_key[..], &withdrawal_amount[..]].concat().into();
    // Ensure input length is correct
    assert_eq!(input.len(), 56);

    // Generate genesis block header with gas limit, gas used, and receipts root
    let mut header = chain_spec.genesis_header();
    header.gas_limit = 1_500_000;
    header.gas_used = 134_807;
    header.receipts_root =
        b256!("b31a3e47b902e9211c4d349af4e4c5604ce388471e79ca008907ae4616bb0ed3");

    // Create a transaction signed by the sender for withdrawal request
    let tx = sign_tx_with_key_pair(
        sender_key_pair,
        Transaction::Legacy(TxLegacy {
            chain_id: Some(chain_spec.chain.id()),
            nonce: 1,
            gas_price: header.base_fee_per_gas.unwrap().into(),
            gas_limit: 134_807,
            to: TxKind::Call(WITHDRAWAL_REQUEST_PREDEPLOY_ADDRESS),
            value: U256::from(1),
            input,
        }),
    );

    // Create an executor provider from chain spec
    let provider = executor_provider(chain_spec);

    // Create an executor from state provider
    let executor = provider.executor(StateProviderDatabase::new(&db));

    // Execute the block and capture execution result
    let BlockExecutionOutput { receipts, requests, .. } = executor
        .execute(
            (
                &Block {
                    header,
                    body: vec![tx],
                    ommers: vec![],
                    withdrawals: None,
                    requests: None,
                }
                .with_recovered_senders()
                .unwrap(),
                U256::ZERO,
            )
                .into(),
        )
        .unwrap();

    // Check the receipt and request for withdrawal details
    let receipt = receipts.first().unwrap();
    assert!(receipt.success);

    let request = requests.first().unwrap();
    let withdrawal_request = request.as_withdrawal_request().unwrap();
    assert_eq!(withdrawal_request.source_address, sender_address);
    assert_eq!(withdrawal_request.validator_pubkey, validator_public_key);
    assert_eq!(
        withdrawal_request.amount,
        u64::from_be_bytes(withdrawal_amount.into())
    );
}

// Test for block gas limit error scenario
fn block_gas_limit_error() {
    // Create a chain specification with Prague fork activated
    let chain_spec = Arc::new(
        ChainSpecBuilder::from(&*MAINNET)
            .shanghai_activated()
            .with_fork(EthereumHardfork::Prague, ForkCondition::Timestamp(0))
            .build(),
    );

    // Create a state provider with withdrawal requests contract deployed
    let mut db = create_state_provider_with_withdrawal_requests_contract();

    // Initialize Secp256k1 for key pair generation
    let secp = Secp256k1::new();
    // Generate a new key pair for the sender
    let sender_key_pair = Keypair::new(&secp, &mut generators::rng());
    // Get the sender's address from the public key
    let sender_address = public_key_to_address(sender_key_pair.public_key());

    // Insert sender's account into the state with nonce, balance, and bytecode hash
    db.insert_account(
        sender_address,
        Account { nonce: 1, balance: U256::from(ETH_TO_WEI), bytecode_hash: None },
        None,
        HashMap::new(),
    );

    // Define validator public key and withdrawal amount as fixed bytes
    let validator_public_key =
        fixed_bytes!("111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111");
    let withdrawal_amount = fixed_bytes!("2222222222222222");
    // Concatenate validator public key and withdrawal amount into input bytes
    let input: Bytes = [&validator_public_key[..], &withdrawal_amount[..]].concat().into();
    // Ensure input length is correct
    assert_eq!(input.len(), 56);

    // Create a genesis block header with specified gas limit, gas used, and receipts root
    let mut header = chain_spec.genesis_header();
    header.gas_limit = 1_500_000;
    header.gas_used = 134_807;
    header.receipts_root =
        b256!("b31a3e47b902e9211c4d349af4e4c5604ce388471e79ca008907ae4616bb0ed3");

    // Create a transaction with a gas limit higher than the block gas limit
    let tx = sign_tx_with_key_pair(
        sender_key_pair,
        Transaction::Legacy(TxLegacy {
            chain_id: Some(chain_spec.chain.id()),
            nonce: 1,
            gas_price: header.base_fee_per_gas.unwrap().into(),
            gas_limit: 2_500_000, // higher than block gas limit
            to: TxKind::Call(WITHDRAWAL_REQUEST_PREDEPLOY_ADDRESS),
            value: U256::from(1),
            input,
        }),
    );

    // Create an executor provider from chain spec
    let executor_provider = executor_provider(chain_spec);

    // Create an executor from state provider
    let executor = executor_provider.executor(StateProviderDatabase::new(&db));

    // Execute the block and expect an error due to gas limit exceeding block limit
    let exec_result = executor.execute(
        (
            &Block {
                header,
                body: vec![tx],
                ommers: vec![],
                withdrawals: None,
                requests: None,
            }
            .with_recovered_senders()
            .unwrap(),
            U256::ZERO,
        )
            .into(),
    );

    // Assert that the error returned is due to exceeding block gas limit
    match exec_result {
        Ok(_) => panic!("Expected block gas limit error"),
        Err(err) => assert_eq!(
            *err.as_validation().unwrap(),
            BlockValidationError::TransactionGasLimitMoreThanAvailableBlockGas {
                transaction_gas_limit: 2_500_000,
                block_available_gas: 1_500_000,
            }
        ),
    }
}

    