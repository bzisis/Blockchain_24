//! Ethereum EVM support

// Re-exporting EthExecutorProvider from reth_evm_ethereum module
#[doc(inline)]
pub use reth_evm_ethereum::execute::EthExecutorProvider;

// Re-exporting EthEvmConfig from reth_evm_ethereum module
#[doc(inline)]
pub use reth_evm_ethereum::EthEvmConfig;
