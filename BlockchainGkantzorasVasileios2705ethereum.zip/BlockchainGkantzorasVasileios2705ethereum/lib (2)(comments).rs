//! EVM config for vanilla ethereum.

// HTML documentation attributes
#![doc(
    html_logo_url = "https://raw.githubusercontent.com/paradigmxyz/reth/main/assets/reth-docs.png",
    html_favicon_url = "https://avatars0.githubusercontent.com/u/97369466?s=256",
    issue_tracker_base_url = "https://github.com/paradigmxyz/reth/issues/"
)]

// Conditionally warn unused crate dependencies except in tests
#![cfg_attr(not(test), warn(unused_crate_dependencies))]

// Conditionally enable features for documentation
#![cfg_attr(docsrs, feature(doc_cfg, doc_auto_cfg))]

// Conditionally disable standard library features
#![cfg_attr(not(feature = "std"), no_std)]

// Conditionally import `alloc` crate when standard library is disabled
#[cfg(not(feature = "std"))]
extern crate alloc;

// External imports
use reth_chainspec::{ChainSpec, Head}; // Import from `reth_chainspec`
use reth_evm::{ConfigureEvm, ConfigureEvmEnv}; // Import from `reth_evm`
use reth_primitives::{transaction::FillTxEnv, Address, Header, TransactionSigned, U256}; // Import from `reth_primitives`
use reth_revm::{Database, EvmBuilder}; // Import from `reth_revm`
use revm_primitives::{AnalysisKind, CfgEnvWithHandlerCfg, TxEnv}; // Import from `revm_primitives`

// Internal module declaration
mod config;
pub use config::{revm_spec, revm_spec_by_timestamp_after_merge}; // Re-export from internal `config` module

// Public submodule for execution logic
pub mod execute;

/// Ethereum DAO hardfork state change data.
pub mod dao_fork;

/// [EIP-6110](https://eips.ethereum.org/EIPS/eip-6110) handling.
pub mod eip6110;

/// Ethereum-related EVM configuration.
#[derive(Debug, Clone, Copy, Default)]
#[non_exhaustive]
pub struct EthEvmConfig;

// Implementation of `ConfigureEvmEnv` for `EthEvmConfig`
impl ConfigureEvmEnv for EthEvmConfig {
    // Method to fill configuration environment (`CfgEnvWithHandlerCfg`)
    fn fill_cfg_env(
        cfg_env: &mut CfgEnvWithHandlerCfg,
        chain_spec: &ChainSpec,
        header: &Header,
        total_difficulty: U256,
    ) {
        // Determine the spec ID using `revm_spec` function from `config` module
        let spec_id = config::revm_spec(
            chain_spec,
            &Head {
                number: header.number,
                timestamp: header.timestamp,
                difficulty: header.difficulty,
                total_difficulty,
                hash: Default::default(),
            },
        );

        // Configure chain ID
        cfg_env.chain_id = chain_spec.chain().id();

        // Set performance analysis mode for created bytecodes
        cfg_env.perf_analyse_created_bytecodes = AnalysisKind::Analyse;

        // Assign the determined spec ID to handler configuration
        cfg_env.handler_cfg.spec_id = spec_id;
    }

    // Method to fill transaction environment (`TxEnv`)
    fn fill_tx_env(&self, tx_env: &mut TxEnv, transaction: &TransactionSigned, sender: Address) {
        // Call `fill_tx_env` method on `TransactionSigned` to populate `tx_env`
        transaction.fill_tx_env(tx_env, sender);
    }
}

// Implementation of `ConfigureEvm` for `EthEvmConfig`
impl ConfigureEvm for EthEvmConfig {
    // Specify default external context type as `()`
    type DefaultExternalContext<'a> = ();

    // Method to instantiate EVM (`Evm`) using provided database (`DB`)
    fn evm<'a, DB: Database + 'a>(
        &self,
        db: DB,
    ) -> reth_revm::Evm<'a, Self::DefaultExternalContext<'a>, DB> {
        // Use `EvmBuilder` to build EVM instance with given database
        EvmBuilder::default().with_db(db).build()
    }
}

// Tests module
#[cfg(test)]
mod tests {
    use super::*; // Import all symbols from outer scope

    // Import necessary symbols from `reth_primitives` and `revm_primitives` for testing
    use reth_chainspec::ChainSpec;
    use reth_primitives::{
        revm_primitives::{BlockEnv, CfgEnv, SpecId},
        Header, U256,
    };
    use revm_primitives::CfgEnvWithHandlerCfg;

    // Unit test for `fill_cfg_and_block_env` method
    #[test]
    #[ignore] // Ignore this test for now
    fn test_fill_cfg_and_block_env() {
        // Initialize environment and configuration structures
        let mut cfg_env = CfgEnvWithHandlerCfg::new_with_spec_id(CfgEnv::default(), SpecId::LATEST);
        let mut block_env = BlockEnv::default();
        let header = Header::default();
        let chain_spec = ChainSpec::default();
        let total_difficulty = U256::ZERO;

        // Call `fill_cfg_and_block_env` method from `EthEvmConfig`
        EthEvmConfig::fill_cfg_and_block_env(
            &mut cfg_env,
            &mut block_env,
            &chain_spec,
            &header,
            total_difficulty,
        );

        // Assert that chain ID matches chain specification ID
        assert_eq!(cfg_env.chain_id, chain_spec.chain().id());
    }
}
